/// Generate by [flutter_assets_generator](https://github.com/goodswifter/flutter_assets_generator) library.
///
/// PLEASE DO NOT EDIT MANUALLY.
class R {
  const R._();

  /// ![preview](file:///home/malak-younis/programming/Dalel App/dalel_app/assets/images/on_boarding1.png)
  static const String assetsImagesOnBoarding1Png =
      'assets/images/on_boarding1.png';
}
