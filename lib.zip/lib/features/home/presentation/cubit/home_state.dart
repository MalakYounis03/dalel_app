class HomeState {}

final class HomeInitial extends HomeState {}
