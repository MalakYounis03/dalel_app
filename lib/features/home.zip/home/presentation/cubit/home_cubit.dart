import 'package:bloc/bloc.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dalel_app/core/utils/app_strings.dart';
import 'package:dalel_app/features/home/data/models/historical_character_model.dart';
import 'package:dalel_app/features/home/data/models/historical_periods_model.dart';
import 'package:dalel_app/features/home/data/models/wars_model.dart';
import 'package:dalel_app/features/home/presentation/cubit/home_state.dart';

class HomeCubit extends Cubit<HomeState> {
  HomeCubit() : super(HomeInitial());

  final periodsCol = FirebaseFirestore.instance.collection(
    FireBaseStrings.historicalPeriods,
  );

  final List<HistoricalPeriodsModel> historicalPeriods = [];
  final List<HistoricalCharacterModel> historicalCharactersList = [];

  // ✅ صحّح الاسم
  Future<void> getHistoricalPeriods() async {
    emit(GetHistoricalPeriodsLoading());
    historicalPeriods.clear();

    try {
      final snapshot = await periodsCol.get();

      // استخدم for..in مع await
      for (final doc in snapshot.docs) {
        // حروب الفترة تُجمع محليًا لكل فترة، مش في قائمة مشتركة
        final wars = await _getWarsForPeriod(doc.id);

        // IMPORTANT: احتفظ بالـ id في الموديل
        historicalPeriods.add(HistoricalPeriodsModel.fromDoc(doc, wars));
      }

      emit(GetHistoricalPeriodsSuccess());

      // ملاحظة:
      // لا تنادِي getRecommendations هنا لكل الفترات.
      // نادِها عندما المستخدم يفتح تفاصيل فترة معيّنة:
      // getRecommendations(periodId)
      // وإن حابب بالـ Home تعرض توصيات أول فترة:
      // if (historicalPeriods.isNotEmpty) {
      //   await getRecommendations(historicalPeriods.first.id);
      // }
    } catch (e) {
      emit(GetHistoricalPeriodsFailure(errMessage: e.toString()));
    }
  }

  Future<List<WarsModel>> _getWarsForPeriod(String periodId) async {
    final wars = <WarsModel>[];
    final snap = await periodsCol
        .doc(periodId)
        .collection(FireBaseStrings.wars)
        .get();
    for (final d in snap.docs) {
      wars.add(WarsModel.fromJson(d.data()));
    }
    return wars;
  }

  Future<void> getRecommendations(String periodId) async {
    emit(GetHistoricalCharactersLoading());
    historicalCharactersList.clear();

    try {
      final snap = await periodsCol
          .doc(periodId)
          .collection(
            FireBaseStrings.recommendations,
          ) // يجب أن تطابق اسم الساب-كولكشن في فايرستور
          .get();

      for (final d in snap.docs) {
        historicalCharactersList.add(
          HistoricalCharacterModel.fromJson(d.data()),
        );
      }
      emit(GetHistoricalCharactersSuccess());
    } catch (e) {
      emit(GetHistoricalCharactersFailure(errMessage: e.toString()));
    }
  }
}
