import 'package:dalel_app/core/utils/app_strings.dart';
import 'package:dalel_app/core/widgets/custom_header_text.dart';
import 'package:dalel_app/features/home/data/models/historical_periods_model.dart';
import 'package:dalel_app/features/home/presentation/cubit/home_cubit.dart';
import 'package:dalel_app/features/home/presentation/widgets/custom_category_list_view.dart';
import 'package:dalel_app/features/home/presentation/widgets/home_sections.dart';
import 'package:dalel_app/features/home/presentation/widgets/period_details_section.dart';
import 'package:dalel_app/features/home/presentation/widgets/period_wars_section.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class HistoricalPeriodsDetailsView extends StatefulWidget {
  const HistoricalPeriodsDetailsView({super.key, required this.model});
  final HistoricalPeriodsModel model;

  @override
  State<HistoricalPeriodsDetailsView> createState() =>
      _HistoricalPeriodsDetailsViewState();
}

class _HistoricalPeriodsDetailsViewState
    extends State<HistoricalPeriodsDetailsView> {
  @override
  void initState() {
    super.initState();
    context.read<HomeCubit>().getRecommendations(widget.model.id);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 16),
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(child: HomeAppBarSection()),
            SliverToBoxAdapter(child: SizedBox(height: 7)),
            SliverToBoxAdapter(
              child: PeriodDetailsSection(
                periodName: widget.model.name,
                description: widget.model.description,
                imageUrl: widget.model.image,
              ),
            ),
            SliverToBoxAdapter(child: SizedBox(height: 22)),

            SliverToBoxAdapter(
              child: PeriodWarsSection(warsList: widget.model.wars),
            ),

            SliverToBoxAdapter(child: RecommendationsSection()),
          ],
        ),
      ),
    );
  }
}

class RecommendationsSection extends StatelessWidget {
  const RecommendationsSection({super.key});
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: 20),
        CustomHeaderText(text: AppStrings.recommendations),
        SizedBox(height: 16),
        CustomCategoryListView(
          dataList: context.read<HomeCubit>().historicalCharactersList,
          routePath: "/CharacterDetailsView",
        ),
        SizedBox(height: 32),
      ],
    );
  }
}
