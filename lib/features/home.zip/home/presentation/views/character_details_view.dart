import 'package:flutter/material.dart';

class CharacterDetailsView extends StatelessWidget {
  const CharacterDetailsView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: Text("HistoricalCharactersListViewItem")),
    );
  }
}
