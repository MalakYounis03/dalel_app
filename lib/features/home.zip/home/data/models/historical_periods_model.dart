import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dalel_app/core/model/data_model.dart';
import 'package:dalel_app/core/utils/app_strings.dart';
import 'package:dalel_app/features/home/data/models/wars_model.dart';

class HistoricalPeriodsModel extends DataModel {
  final String id;
  final List<WarsModel> wars;

  HistoricalPeriodsModel({
    required this.id,
    required super.name,
    required super.image,
    required super.description,
    required this.wars,
  });

  factory HistoricalPeriodsModel.fromDoc(
    QueryDocumentSnapshot<Map<String, dynamic>> doc,
    List<WarsModel> warsList,
  ) {
    final data = doc.data();
    return HistoricalPeriodsModel(
      id: doc.id,
      name: data[FireBaseStrings.name],
      image: data[FireBaseStrings.image],
      description: data[FireBaseStrings.description],
      wars: warsList,
    );
  }
}
